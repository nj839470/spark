l1 = [2, 3, 4, 5]
l2 = [6, 7, 8, 9]
# append
appendlst = l1.append(l2)
print(l1)

# extend
l1.extend(l2)
print(l1)
